﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private double[] numbers = new double[0];
        public MainWindow()
        {
            InitializeComponent();
            ResultText.Text = string.Empty;
            OperationText.Text = string.Empty;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;

            string currentNumber = button.Name.Trim(new char[] { 'B','u','t','o','n'});

            if (((OperationText.Text is null || OperationText.Text == "" || OperationText.Text == "0") && (currentNumber == "00" || currentNumber == "0")))
                OperationText.Text = "0";
            else
                OperationText.Text += currentNumber;
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
                AddNumber('+');
        }

        private void ButtonMinus_Click(object sender, RoutedEventArgs e)
        {
                AddNumber('-');
        }

        private void ButtonMultiply_Click(object sender, RoutedEventArgs e)
        {
                AddNumber('*');
        }

        private void ButtonDivide_Click(object sender, RoutedEventArgs e)
        {
                AddNumber('÷');
        }

        private void ButtonResult_Click(object sender, RoutedEventArgs e)
        {
            ResultText.Text = Result();
            OperationText.Text = string.Empty;
        }

        private string Result()
        {
            AddNumber("");
            double result = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                result += numbers[i];
            }
            return $"{result:f2}";
        }

        private void AddNumber<T>(T action)
        {
            switch (CheckAllreadyOperation())
            {
                case 0: ResultText.Text = ResultText.Text.Remove(ResultText.Text.Length - 1) + action; 
                    break;
                case 1:
                    numbers = new[] { double.Parse(ResultText.Text) };
                    ResultText.Text += action;
                    break;
                case 2:
                    string number = OperationText.Text;
                    if (CheckOperation(ref number))
                    {
                        Proc(ref number);
                        Array.Resize(ref numbers, numbers.Length + 1);
                        numbers[numbers.Length - 1] = double.Parse(number);
                    }
                    ResultText.Text += OperationText.Text + action;
                    OperationText.Text = string.Empty;
                    break;
            }   
        }
        private void Multipy(string number) => numbers[numbers.Length - 1] *= double.Parse(number);
        private void Div(string number) => numbers[numbers.Length - 1] /= double.Parse(number);
        private bool Proc(ref string number)
        {
            if (OperationText.Text[OperationText.Text.Length - 1] == '%')
            {
                number = ((numbers[numbers.Length - 1] * double.Parse(number.Remove(number.Length - 1))) / 100).ToString();
                return true;
            }
            else return false;
        }
        
        private bool CheckOperation(ref string number)
        {
            if(ResultText.Text.Length != 0)
            switch (ResultText.Text[ResultText.Text.Length - 1])
            {
                case '-': number = string.Concat('-', number); 
                        return true;
                case '*':
                        if(Proc(ref number)) Div(number);
                        else Multipy(number);
                        return false;
                case '÷': 
                        if(Proc(ref number))Multipy(number);
                        else Div(number); 
                        return false;
                default:
                        return true;
            }
            else return true;
        }

        private void ButtonDOT_Click(object sender, RoutedEventArgs e)
        {
            if (OperationText.Text[OperationText.Text.Length - 1] != ',')
            OperationText.Text += ',';
        }

        private void Delite_Click(object sender, RoutedEventArgs e)
        {
            if (OperationText.Text == "")
            {
                ResultText.Text = string.Empty;
                numbers = new double[0];
            }
            else
                OperationText.Text = OperationText.Text.Remove(OperationText.Text.Length - 1);
        }

        private byte CheckAllreadyOperation()
        {
            if(OperationText.Text == "" || OperationText.Text is null)
            switch (ResultText.Text[ResultText.Text.Length - 1])
            {
                case '+':
                    return 0;
                case '-':  
                    return 0;
                case '*':  
                    return 0;
                case '÷':  
                    return 0;
                default:
                    return 1;
            }
            else return 2;
        }

        private void ButtonSqrt_Click(object sender, RoutedEventArgs e)
        {
            if(ResultText.Text == "" && OperationText.Text!="")
            {
                ResultText.Text = $"{Math.Sqrt(double.Parse(OperationText.Text)):f2}";
                OperationText.Text = string.Empty;
            } else if(ResultText.Text != "")
              ResultText.Text = $"{Math.Sqrt(double.Parse(Result())):f2}";
        }

        private void ButtonProc_Click(object sender, RoutedEventArgs e)
        {
            OperationText.Text += '%';
        }
    }
}
